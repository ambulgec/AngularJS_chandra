
var app = angular.module("Sujit", ["authmodule", "catlogmodule"]);

