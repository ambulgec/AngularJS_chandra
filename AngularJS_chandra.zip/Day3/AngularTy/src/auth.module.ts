import * as angular from 'angular';
import { MyLoginController } from 'controller/login.controller';
 
angular.module('myLoginApp', []);
angular.module('myLoginApp').controller('MyLoginController', MyLoginController);