

function validate()
{
    let status=false;
    let emailAddress=document.getElementById("email").value;
    let password=document.getElementById("password").value;

    if(emailAddress === "sujit" && password === "sujit")
    {
       status=true;
    }
    
}