

function authentication(email,pass)
{
    alert("authecation called");
    let email=document.getElementById("email").ariaValueMax;
    let pass=document.getElementById("password").ariaValueMax;
    validate(email,pass);
}