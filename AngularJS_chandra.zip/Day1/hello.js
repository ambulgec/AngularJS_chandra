var count = 45;
var status = false; 
var name = "sujit";
var product = {
    "company": "Tsysteam",  
    "Title": "Imedone",
    "version": 2020
};

count++;

if (status) {
    console.log("Product is live on production");
} else {
    console.log("Product is on development");
}


console.log("Welcome to our system");  
