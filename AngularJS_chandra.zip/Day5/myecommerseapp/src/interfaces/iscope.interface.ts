import angular from "angular";
export interface IScopeCustom extends angular.IScope {
    vm: any;
}