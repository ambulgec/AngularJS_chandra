export interface Product{
    id: string,
    name: string,
    type: string,
    subtype: string,
    price: string,
    imgSrc: string
}