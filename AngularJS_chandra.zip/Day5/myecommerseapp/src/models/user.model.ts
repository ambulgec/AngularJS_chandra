export interface User{
    Id: string;
    Name: string;
    PhoneNumber: string;
    Address: string
}